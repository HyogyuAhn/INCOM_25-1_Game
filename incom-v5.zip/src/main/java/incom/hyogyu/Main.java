package incom.hyogyu;

import incom.hyogyu.gui.GUIManager;

public class Main {

    public static void main(String[] args) {
        new GUIManager();
    }

}
